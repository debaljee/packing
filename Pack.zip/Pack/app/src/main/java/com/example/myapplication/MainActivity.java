package com.example.myapplication;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View.OnTouchListener;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.example.myapplication.R;

public class MainActivity extends Activity {
    private float screenWidth;
    private float screenHeight;
    private int unitState;
    private float destination;
    private float current;
    private  HorizontalScrollView scroller;
    private HorizontalScrollView myMenuExp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(savedInstanceState==null)
         unitState=1;

    }
    
    protected void onStart(){
      super.onStart();
      DisplayMetrics metrics=this.getResources()
      .getDisplayMetrics();
      screenWidth=metrics.widthPixels;
      screenHeight=metrics.heightPixels;
      if(screenWidth<screenHeight){
        WebView view=(WebView)
        findViewById(R.id.background);
        view.loadUrl("http://localhost:5000/travel");
        TextView heading=(TextView)
        findViewById(R.id.heading);
        Typeface face=Typeface.createFromAsset(
        getAssets(),"open.ttf");
        heading.setTypeface(face);
        float textSize=(4*screenHeight)/100;
        heading.setTextSize(TypedValue.COMPLEX_UNIT_PX,
        textSize);
        TextView subHeading=(TextView)
        findViewById(R.id.subHeading);
        subHeading.setTypeface(face);
        float subHeadingSize=(3*screenHeight)/100;
        subHeading.setTextSize(TypedValue.COMPLEX_UNIT_PX,
        subHeadingSize);
        EditText enterDistance=(EditText)
        findViewById(R.id.enterDistance);
        enterDistance.setShowSoftInputOnFocus(false);
        float inpW=(68*screenWidth)/100;
        LinearLayout.LayoutParams params=
        new LinearLayout.LayoutParams(
         (int)inpW,
         LinearLayout.LayoutParams.MATCH_PARENT
        );
        float inpM=(1*screenWidth)/100;
        params.setMargins((int)inpM,(int)inpM,
                          (int)inpM,(int)inpM);
        enterDistance.setLayoutParams(params);
        TextView unit1=(TextView)
        findViewById(R.id.unit1);
        unit1.setTypeface(face);
        float unitWidth=(30*screenWidth)/100;
        unit1.getLayoutParams().width=(int)unitWidth;
        TextView unit2=(TextView)
        findViewById(R.id.unit2);
        unit2.getLayoutParams().width=(int)unitWidth;
        unit2.setTypeface(face);
        scroller=(HorizontalScrollView)
        findViewById(R.id.unitSelect);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setSmoothScrollingEnabled(true);
        scroller.post(new Runnable(){
          @Override
          public void run(){
            scroller.scrollTo((int)screenWidth,0);
          }
        });
        scroller.setOnTouchListener(
        new OnTouchListener(){
          @Override
          public boolean onTouch(View view,
                                 MotionEvent event){
            if(event.getAction()==MotionEvent.ACTION_UP){
              float threshold=(15*screenWidth)/100;
              current=scroller.getScrollX();
              if(current<threshold)
              {
                 destination=0;
                 scrollDown();
              }
              else{
                destination=(2*threshold);
                scrollUp();
              }
              return true;
            }
            return false;
          }
        });
        float menuWidth=(80*screenWidth)/100;
        LinearLayout sideBar=(LinearLayout)
        findViewById(R.id.sideBar);
        sideBar.getLayoutParams().width=(int)menuWidth;
        LinearLayout freeSpace=(LinearLayout)
        findViewById(R.id.freeSpace);
        freeSpace.getLayoutParams().width=(int)screenWidth;
        freeSpace.setVisibility(View.INVISIBLE);
        myMenuExp=
        (HorizontalScrollView)findViewById(R.id.myMenuExp);
        myMenuExp.setHorizontalScrollBarEnabled(false);
 //       myMenuExp.post(new Runnable(){
//          @Override
   //       public void run(){
 //           float sc=(80*screenWidth)/100;
  //          myMenuExp.scrollTo((int)sc,0);
  //        }
     //   });
        //myMenuExp.setVisibility(View.GONE);
        ImageView expand=(ImageView)
        findViewById(R.id.expand);
        float expandWidth=(10*screenWidth)/100;
        float expandHeight=(10*screenWidth)/100;
        RelativeLayout.LayoutParams body=
        new RelativeLayout.LayoutParams
        ((int)expandWidth,
         (int)expandHeight);
        float mTop=(50*screenHeight)/100;
        float mLeft=(38*screenWidth)/100;
        body.setMargins((int)mLeft,(int)mTop,0,0);
        expand.setLayoutParams(body);
        ImageView exit=(ImageView)
        findViewById(R.id.exit);
        RelativeLayout.LayoutParams exitBody=
        new RelativeLayout.LayoutParams(
        (int)expandWidth,
        (int)expandHeight);
        mLeft=(52*screenWidth)/100;
        exitBody.setMargins((int)mLeft,(int)mTop,0,0);
        exit.setLayoutParams(exitBody);
        
        
        LinearLayout expandableMenu=(LinearLayout)
        findViewById(R.id.expandableMenu);
        RelativeLayout.LayoutParams expBody=
        new RelativeLayout.LayoutParams(
        (int)menuWidth,
        RelativeLayout.LayoutParams.MATCH_PARENT
        );
        expandableMenu.setLayoutParams(expBody);
        expandableMenu.setVisibility(View.GONE);
        
        ImageView settingImg=(ImageView)
        findViewById(R.id.settingImg);
        float iWidth=(20*screenWidth)/100;
        settingImg.getLayoutParams().width=(int)iWidth;
        settingImg.getLayoutParams().height=(int)iWidth;
        ImageView aboutUs=(ImageView)
        findViewById(R.id.aboutUs);
        aboutUs.getLayoutParams().width=(int)iWidth;
        aboutUs.getLayoutParams().height=(int)iWidth;
        ImageView github=(ImageView)
        findViewById(R.id.github);
        github.getLayoutParams().width=(int)iWidth;
        github.getLayoutParams().height=(int)iWidth;
        ImageView gmail=(ImageView)
        findViewById(R.id.gmail);
        gmail.getLayoutParams().width=(int)iWidth;
        gmail.getLayoutParams().height=(int)iWidth;
        ImageView newSettings=(ImageView)
        findViewById(R.id.newSettings);
        newSettings.getLayoutParams().width=(int)iWidth;
        newSettings.getLayoutParams().height=(int)iWidth;
        ImageView newAboutUs=(ImageView)
        findViewById(R.id.newAboutUs);
        newAboutUs.getLayoutParams().width=(int)iWidth;
        newAboutUs.getLayoutParams().height=(int)iWidth;
        ImageView newGithub=(ImageView)
        findViewById(R.id.newGithub);
        newGithub.getLayoutParams().width=(int)iWidth;
        newGithub.getLayoutParams().height=(int)iWidth;
        ImageView newGmail=(ImageView)
        findViewById(R.id.newGmail);
        newGmail.getLayoutParams().width=(int)iWidth;
        newGmail.getLayoutParams().height=(int)iWidth;
        TextView newSText=(TextView)
        findViewById(R.id.newSText);
        newSText.setTypeface(face);
        TextView newAb=(TextView)
        findViewById(R.id.newAb);
        newAb.setTypeface(face);
        TextView newG=(TextView)
        findViewById(R.id.newG);
        newG.setTypeface(face);
        TextView newGm=(TextView)
        findViewById(R.id.newGm);
        newGm.setTypeface(face);
        TextView st=(TextView)
        findViewById(R.id.st);
        st.setTypeface(face);
        TextView aB=(TextView)
        findViewById(R.id.aB);
        aB.setTypeface(face);
        TextView git=(TextView)
        findViewById(R.id.git);
        git.setTypeface(face);
        TextView gmailText=(TextView)
        findViewById(R.id.gmailText);
        gmailText.setTypeface(face);
        ImageView helpImage=(ImageView)
        findViewById(R.id.helpImage);
        float helpWidth=(20*screenHeight)/100;
        helpImage.getLayoutParams().width=(int)helpWidth;
        helpImage.getLayoutParams().height=(int)helpWidth;
        helpImage.setClipToOutline(true);
        ImageView heart=(ImageView)
        findViewById(R.id.heart);
        float heartHeight=(15*screenWidth)/100;
        heart.getLayoutParams().width=(int)heartHeight;
        heart.getLayoutParams().height=(int)heartHeight;
        ImageView helpMe=(ImageView)
        findViewById(R.id.helpMe);
        helpMe.getLayoutParams().width=(int)helpWidth;
        helpMe.getLayoutParams().height=(int)helpWidth;
        helpMe.setClipToOutline(true);
        ImageView myHeart=(ImageView)
        findViewById(R.id.myHeart);
        myHeart.getLayoutParams().width=(int)heartHeight;
        myHeart.getLayoutParams().height=(int)heartHeight;
      }
    }
    public void grow(View view){
      
    int abc;
    }
    
    private void scrollUp(){
      final Handler handler=new Handler();
      handler.post(new Runnable(){
        @Override
        public void run(){
          if(current<destination){
            scroller.smoothScrollTo((int)(current),0);
            current+=5;
            handler.postDelayed(this,10);
          }
          else
           scroller.smoothScrollTo((int)destination,0);
        }
      });
    }
    
    
    private void scrollDown(){
      final Handler handler=new Handler();
      handler.post(new Runnable(){
        @Override
        public void run(){
          if(current>destination){
            scroller.smoothScrollTo((int)current,0);
            current-=5;
            handler.postDelayed(this,10);
          }
          else
           scroller.smoothScrollTo(0,0);
        }
      });
    }

}
